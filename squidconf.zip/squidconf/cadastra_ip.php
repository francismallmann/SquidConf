<?php

$dados_ip = $_POST["ip_liberado"] .PHP_EOL;

	switch ($_POST["radio"]) {
	
	case "1":
    $abre = fopen("ips_liberados.txt", "a");
	$escreve = fwrite($abre, $dados_ip);
	fclose($abre);
	break;
	
	case "2":
	$abre = fopen("ips_normais.txt", "a");
	$escreve = fwrite($abre, $dados_ip);
	fclose($abre);
	break;
	
	case "3":
	$abre = fopen("ips_limitados.txt", "a");
	$escreve = fwrite($abre, $dados_ip);
	fclose($abre);
	break;
	}
    
echo "<script>
	alert('CADASTRADO COM SUCESSO!'); location= './cadastra_ip.html';
	</script>";?>