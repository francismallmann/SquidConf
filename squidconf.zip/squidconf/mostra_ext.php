<?php

    $abre = fopen("ext_bloqueada.txt", "r");

    while (!feof ($abre)) {
    	$linha = fgets($abre, 4096);
    	echo $linha."<br>";
	}

	fclose($abre);
?>