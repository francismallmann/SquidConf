<?php

$dados_ext = "\." . $_POST["extensao"]."($|\?|\&)";

    $abre = file("ext_bloqueada.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ext){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("ext_bloqueada.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_ext.html';
	</script>";
	
?>