<?php

    $abre = fopen("ips_normais.txt", "r");

    while (!feof ($abre)) {
    	$linha = fgets($abre, 4096);
    	echo $linha."<br>";
	}

	fclose($abre);
?>