<?php

$dados_ext = "\." . $_POST["extensao"]."($|\?|\&)" .PHP_EOL;

	
    $abre = fopen("ext_bloqueada.txt", "a");
	$escreve = fwrite($abre, $dados_ext);
	fclose($abre);
	
    
	echo "<script>
	alert('CADASTRADO COM SUCESSO!'); location= './cadastra_ext.html';
	</script>";
	
?>