<?php

exec("/usr/bin/sudo /usr/bin/service apache2 restart");

$reiniciasquid = exec("/etc/init.d/squid restart");

$output = shell_exec('service squid3 restart');
$restart = system("sudo script");

echo "<script>alert('REINICIADO COM SUCESSO!'); location= './index.html';
	</script>";
?>
