<?php


    $abre = fopen("site_liberados.txt", "r");

    while (!feof ($abre)) {
    	$linha = fgets($abre, 4096);
    	echo $linha."<br>";
	}

	fclose($abre);
?>