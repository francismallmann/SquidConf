<?php

$dados_ip = $_POST["ip_liberado"];

	switch ($_POST["radio"]) {
	
	case "1":
    $abre = file("ips_liberados.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ip){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("ips_liberados.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_ip.html';
	</script>";
	break;
	


	case "2":
	$abre = file("ips_normais.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ip){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("ips_normais.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_ip.html';
	</script>";
	break;
	
	case "3":
    $abre = file("ips_limitados.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ip){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("ips_limitados.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_ip.html';
	</script>";
	break;
	}
    
?>