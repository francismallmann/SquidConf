<?php

$dados_site = $_POST["site"] .PHP_EOL;

	switch ($_POST["radio"]) {
	
	case "1":
    $abre = fopen("site_liberados.txt", "a");
	$escreve = fwrite($abre, $dados_site);
	fclose($abre);
	break;
	
	case "2":
	$abre = fopen("site_bloqueados.txt", "a");
	$escreve = fwrite($abre, $dados_site);
	fclose($abre);
	break;
	
	}
    
echo "<script>
	alert('CADASTRADO COM SUCESSO!'); location= './cadastra_site.html';
	</script>";?>