<?php

    $abre = fopen("site_bloqueados.txt", "r");

    while (!feof ($abre)) {
    	$linha = fgets($abre, 4096);
    	echo $linha."<br>";
	}

	fclose($abre);
?>