<?php

$dados_ip = $_POST["site"];

	switch ($_POST["radio"]) {
	
	case "1":
    $abre = file("site_liberados.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ip){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("site_liberados.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_site.html';
	</script>";
	break;
	


	case "2":
	$abre = file("site_bloqueados.txt");
    $out = array();
    
    foreach ($abre as $line) {
    		if(trim($line) != $dados_ip){
    			$out[] = $line;
    		}
    	}
    $fp = fopen("site_bloqueados.txt", "w+");
    flock($fp, LOCK_EX);
    foreach ($out as $line) {
    		fwrite($fp, $line);
    	}
    flock($fp, LOCK_UN);
    fclose($fp);	

    
	echo "<script>alert('DELETADO COM SUCESSO!'); location= './cadastra_site.html';
	</script>";
	break;
	
	
	}
    
?>